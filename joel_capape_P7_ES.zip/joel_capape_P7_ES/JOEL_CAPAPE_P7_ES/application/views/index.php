<?php
include('views/header.php');
include('views/body.php');
include('views/inicio.php');
?>